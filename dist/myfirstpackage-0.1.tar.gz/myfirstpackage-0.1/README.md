# myfirstpackage 
This library was created as an example showing how to publish your own Python package. 

# building this package locally 
python setup.py sdist 

# installing this package from GitHub 
pip install git+https://github.com/HakimBalogun/myfirstpackage.git 

# updating this package from GitHub 
pip install --upgrade git+https://github.com/HakimBalogun/myfirstpackage.git 

# The End! 
